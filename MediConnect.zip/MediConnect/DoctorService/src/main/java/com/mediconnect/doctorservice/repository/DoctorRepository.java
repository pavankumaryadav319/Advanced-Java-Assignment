package com.mediconnect.doctorservice.repository;

import com.mediconnect.doctorservice.entity.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// JpaRepository gives us built-in CRUD methods:
// save(), findById(), findAll(), deleteById(), existsById() etc.
// We don't need to write SQL queries for basic operations
@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {

    // We can add custom query methods here if needed in the future
    // Example: List<Doctor> findBySpecialization(String specialization);

}
