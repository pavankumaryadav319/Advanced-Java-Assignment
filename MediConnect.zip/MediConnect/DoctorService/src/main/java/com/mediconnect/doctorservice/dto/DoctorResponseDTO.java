package com.mediconnect.doctorservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// DTO used when sending doctor data BACK to the client
// Also used by AppointmentService via Feign Client to get doctor details
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DoctorResponseDTO {

    private Long doctorId;
    private String name;
    private String specialization;
    private Integer experience;
    private String hospitalName;
    private String availability;

}
