package com.mediconnect.appointmentservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

// DTO used when client sends data to book an appointment
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentRequestDTO {

    private String patientName;
    private Long doctorId;
    private LocalDate appointmentDate;

}
