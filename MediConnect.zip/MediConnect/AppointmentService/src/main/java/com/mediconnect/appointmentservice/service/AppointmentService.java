package com.mediconnect.appointmentservice.service;

import com.mediconnect.appointmentservice.dto.AppointmentRequestDTO;
import com.mediconnect.appointmentservice.dto.AppointmentResponseDTO;
import com.mediconnect.appointmentservice.dto.DoctorResponseDTO;
import com.mediconnect.appointmentservice.entity.Appointment;
import com.mediconnect.appointmentservice.feign.DoctorFeignClient;
import com.mediconnect.appointmentservice.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    // Feign Client to call Doctor Service
    @Autowired
    private DoctorFeignClient doctorFeignClient;

    // ==================== CREATE APPOINTMENT ====================
    public AppointmentResponseDTO createAppointment(AppointmentRequestDTO requestDTO) {

        // Step 1: Call Doctor Service using Feign Client to validate doctor exists
        // If doctor does not exist, Doctor Service throws exception -> Feign propagates error
        ResponseEntity<DoctorResponseDTO> doctorResponse = doctorFeignClient.getDoctorById(requestDTO.getDoctorId());

        // Step 2: Check if we got a valid response from Doctor Service
        if (doctorResponse.getBody() == null) {
            throw new RuntimeException("Doctor not found with ID: " + requestDTO.getDoctorId()
                    + ". Cannot book appointment.");
        }

        // Step 3: Doctor exists, so proceed to create appointment
        Appointment appointment = new Appointment();
        appointment.setPatientName(requestDTO.getPatientName());
        appointment.setDoctorId(requestDTO.getDoctorId());
        appointment.setAppointmentDate(requestDTO.getAppointmentDate());
        appointment.setStatus("SCHEDULED");  // default status when appointment is first created

        // Step 4: Save to database
        Appointment savedAppointment = appointmentRepository.save(appointment);

        // Step 5: Return response
        return convertToResponseDTO(savedAppointment);
    }

    // ==================== GET ALL APPOINTMENTS ====================
    public List<AppointmentResponseDTO> getAllAppointments() {
        List<Appointment> appointments = appointmentRepository.findAll();

        return appointments.stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
    }

    // ==================== GET APPOINTMENT BY ID ====================
    public AppointmentResponseDTO getAppointmentById(Long appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found with ID: " + appointmentId));

        return convertToResponseDTO(appointment);
    }

    // ==================== CANCEL APPOINTMENT ====================
    public String cancelAppointment(Long appointmentId) {
        if (!appointmentRepository.existsById(appointmentId)) {
            throw new RuntimeException("Appointment not found with ID: " + appointmentId);
        }

        appointmentRepository.deleteById(appointmentId);
        return "Appointment with ID " + appointmentId + " has been cancelled successfully.";
    }

    // ==================== HELPER METHOD ====================
    private AppointmentResponseDTO convertToResponseDTO(Appointment appointment) {
        AppointmentResponseDTO responseDTO = new AppointmentResponseDTO();
        responseDTO.setAppointmentId(appointment.getAppointmentId());
        responseDTO.setPatientName(appointment.getPatientName());
        responseDTO.setDoctorId(appointment.getDoctorId());
        responseDTO.setAppointmentDate(appointment.getAppointmentDate());
        responseDTO.setStatus(appointment.getStatus());
        return responseDTO;
    }

}
