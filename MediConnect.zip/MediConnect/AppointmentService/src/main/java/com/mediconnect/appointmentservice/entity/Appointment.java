package com.mediconnect.appointmentservice.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Table(name = "appointments")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long appointmentId;

    @Column(nullable = false)
    private String patientName;

    // We only store doctorId here, NOT the full Doctor object
    // This is because in microservices, each service manages its own data
    // Doctor details will be fetched from Doctor Service using Feign Client when needed
    @Column(nullable = false)
    private Long doctorId;

    @Column(nullable = false)
    private LocalDate appointmentDate;

    // e.g., "SCHEDULED", "COMPLETED", "CANCELLED"
    @Column(nullable = false)
    private String status;

}
