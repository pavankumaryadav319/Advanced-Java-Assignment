package com.mediconnect.appointmentservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// This is a COPY of DoctorResponseDTO from Doctor Service
// We need this class here so that Feign Client can deserialize the response
// received from Doctor Service into a Java object
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DoctorResponseDTO {

    private Long doctorId;
    private String name;
    private String specialization;
    private Integer experience;
    private String hospitalName;
    private String availability;

}
