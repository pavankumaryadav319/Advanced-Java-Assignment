package com.mediconnect.appointmentservice.feign;

import com.mediconnect.appointmentservice.dto.DoctorResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// @FeignClient is the key annotation here
// name = "DOCTOR-SERVICE" must exactly match the spring.application.name in Doctor Service's properties
// Feign Client will automatically pick the correct instance using Eureka + Load Balancing
@FeignClient(name = "DOCTOR-SERVICE")
public interface DoctorFeignClient {

    // This method signature must match the endpoint in DoctorController exactly
    // GET /doctors/{id}  ->  getDoctorById in DoctorController
    @GetMapping("/doctors/{id}")
    ResponseEntity<DoctorResponseDTO> getDoctorById(@PathVariable("id") Long doctorId);

}
