package com.mediconnect.appointmentservice.repository;

import com.mediconnect.appointmentservice.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {

    // We can add custom queries here if needed
    // Example: List<Appointment> findByDoctorId(Long doctorId);

}
